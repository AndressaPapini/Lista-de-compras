import { useState } from 'react';
import {
  Alert,
  Button,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

type FormularioItemProps = {
  aoAdicionar: (nome: string, quantidade: number) => void;
};

export default function FormularioItem({ aoAdicionar }: FormularioItemProps) {
  const [nome, setNome] = useState('');
  const [quantidade, setQuantidade] = useState('');

  function lidarComAdicao(): void {
    const nomeLimpo = nome.trim();
    if (!nomeLimpo) {
      Alert.alert('Atenção', 'Digite o nome do produto.');
      return;
    }

    const quantidadeInformada = quantidade.trim();
    const qtd = quantidadeInformada === '' ? 1 : Number(quantidadeInformada);
    if (!Number.isInteger(qtd) || qtd < 1) {
      Alert.alert('Atenção', 'Digite uma quantidade inteira maior que zero.');
      return;
    }

    aoAdicionar(nomeLimpo, qtd);
    setNome('');
    setQuantidade('');
  }

  return (
    <View style={estilos.cartao}>
      <Text style={estilos.rotulo}>Novo produto</Text>
      <TextInput
        style={estilos.campo}
        placeholder="Ex.: Arroz, feijão, leite..."
        placeholderTextColor="#9CA3AF"
        value={nome}
        onChangeText={setNome}
        accessibilityLabel="Nome do produto"
        returnKeyType="next"
      />
      <TextInput
        style={estilos.campoQuantidade}
        placeholder="Qtd (padrão: 1)"
        placeholderTextColor="#9CA3AF"
        value={quantidade}
        onChangeText={setQuantidade}
        keyboardType="numeric"
        maxLength={3}
        accessibilityLabel="Quantidade"
      />
      <View style={estilos.areaBotao}>
        <Button title="Adicionar item" color="#4F46E5" onPress={lidarComAdicao} />
      </View>
    </View>
  );
}

const estilos = StyleSheet.create({
  cartao: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginTop: 8,
    padding: 16,
    borderRadius: 16,
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
  },
  rotulo: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 10,
  },
  campo: {
    backgroundColor: '#F3F4F6',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    color: '#1F2937',
    marginBottom: 10,
  },
  campoQuantidade: {
    backgroundColor: '#F3F4F6',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    color: '#1F2937',
    width: 150,
    marginBottom: 14,
  },
  areaBotao: {
    borderRadius: 10,
    overflow: 'hidden',
  },
});
